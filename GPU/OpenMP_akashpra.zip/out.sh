#!/bin/bash
module load intel
cd parallel
make
sbatch SLURM_MPI_Matrix_decomp.sh
sbatch SLURM_MPI_Matrix_decomp2.sh
sbatch SLURM_MPI_Matrix_decomp4.sh
sbatch SLURM_MPI_Matrix_decomp6.sh
sbatch SLURM_MPI_Matrix_decomp8.sh
cd ../seq/
make
sbatch SLURM_MPI_decomp_seq.sh
cd ../Parallel_block/
make
sbatch SLURM_MPI_Matrix_decomp.sh
sbatch SLURM_MPI_Matrix_decomp2.sh
sbatch SLURM_MPI_Matrix_decomp4.sh
sbatch SLURM_MPI_Matrix_decomp6.sh
sbatch SLURM_MPI_Matrix_decomp8.sh

